export interface Product {
    id: string,
    option: string,
    quantity: number
}